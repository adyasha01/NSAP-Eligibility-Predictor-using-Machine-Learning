from flask import Flask, request, jsonify
import joblib
import pandas as pd

model = joblib.load("model.pkl")

app = Flask(__name__)

@app.route("/")
def home():
    return "NSAP Eligibility Predictor API is running."

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    df = pd.DataFrame([data])
    prediction = model.predict(df)[0]
    return jsonify({"predicted_scheme": prediction})

if __name__ == "__main__":
    app.run(debug=True)